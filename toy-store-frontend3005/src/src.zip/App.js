import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HighlightSlider from './components/HighlightSlider';
import ProductList from './components/ProductList';
import ProductDetail from './components/ProductDetail';
import Cart from './pages/Cart';
import MiniCartPopup from './components/MiniCartPopup';
import Checkout from './pages/Checkout';

function HomePage() {
  return (
    <>
      <section style={{ background: '#f8f8f8', padding: '20px' }}>
        <HighlightSlider />
      </section>
      <section style={{ padding: '20px' }}>
        <h2>Danh sách sản phẩm</h2>
        <ProductList />
      </section>
    </>
  );
}

function App() {
  const [showCartPopup, setShowCartPopup] = useState(false);
  const [hoverCart, setHoverCart] = useState(false);

  const handleQtyChange = (productId, delta) => {
    const stored = JSON.parse(localStorage.getItem('cartItems')) || [];
    const updated = stored.map(item =>
      item.productId === productId
        ? { ...item, quantity: Math.max(1, item.quantity + delta) }
        : item
    );
    localStorage.setItem('cartItems', JSON.stringify(updated));
  };

  const handleAddToCartPopup = () => {
    setShowCartPopup(true);
    setTimeout(() => setShowCartPopup(false), 5000);
  };

  return (
    <Router>
      <div className="App">
        <Header
          onCartHover={() => setHoverCart(true)}
          onCartLeave={() => setHoverCart(false)}
          showMiniCart={hoverCart}
          onUpdateQty={handleQtyChange}
        />

        {showCartPopup && !hoverCart && (
          <div style={{ position: 'fixed', top: 95, right: 24, zIndex: 9999 }}>
            <MiniCartPopup onUpdateQty={handleQtyChange} showClose={false} />
          </div>
        )}

        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/products" element={<ProductList />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/product/:id" element={<ProductDetail onAddToCartPopup={handleAddToCartPopup} />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
