import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Cart.css';

const Cart = () => {
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const stored = localStorage.getItem('cartItems');
    if (stored) {
      const parsed = JSON.parse(stored);
      setItems(parsed);
      updateTotal(parsed);
    }
  }, []);

  const updateTotal = (cartItems) => {
    const sum = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
    setTotal(sum);
  };

  const handleQtyChange = (productId, delta) => {
    const updated = items.map(item =>
      item.productId === productId
        ? { ...item, quantity: Math.max(1, item.quantity + delta) }
        : item
    );
    setItems(updated);
    localStorage.setItem('cartItems', JSON.stringify(updated));
    updateTotal(updated);
  };

  const handleRemove = (productId) => {
    const updated = items.filter(item => item.productId !== productId);
    setItems(updated);
    localStorage.setItem('cartItems', JSON.stringify(updated));
    updateTotal(updated);
  };

  const totalItems = items.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="cart-page">
      <h2>Giỏ hàng của bạn</h2>
      <p className="total-items">Tổng số sản phẩm: <strong>{totalItems}</strong></p>

      {items.length === 0 ? (
        <p>Chưa có sản phẩm nào trong giỏ hàng.</p>
      ) : (
        <>
          <table className="cart-table">
            <thead>
              <tr>
                <th>Ảnh</th>
                <th>Sản phẩm</th>
                <th>Giá</th>
                <th>Số lượng</th>
                <th>Thành tiền</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {items.map(item => (
                <tr key={item.productId}>
                  <td><img src={item.urlImage} alt={item.productName} /></td>
                  <td>{item.productName}</td>
                  <td>{item.price.toLocaleString('vi-VN')} ₫</td>
                  <td>
                    <button onClick={() => handleQtyChange(item.productId, -1)}>-</button>
                    <span className="qty">{item.quantity}</span>
                    <button onClick={() => handleQtyChange(item.productId, 1)}>+</button>
                  </td>
                  <td>{(item.price * item.quantity).toLocaleString('vi-VN')} ₫</td>
                  <td><button onClick={() => handleRemove(item.productId)}>🗑</button></td>
                </tr>
              ))}
            </tbody>
          </table>

          <h3 className="total-price">
            Tổng cộng: {total.toLocaleString('vi-VN')} ₫
          </h3>

          <div className="cart-actions">
            <button className="continue-btn" onClick={() => navigate('/products')}>
              Tiếp tục mua sắm
            </button>
            <button className="checkout-btn" onClick={() => navigate('/checkout')}>
              Thanh toán ngay
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default Cart;
