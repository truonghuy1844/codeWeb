import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './Checkout.css';

const Checkout = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [cartItems, setCartItems] = useState([]);
  const [shippingFee, setShippingFee] = useState(0);

  // Truy vấn mode từ URL (?mode=buynow hoặc ?mode=cart)
  const queryParams = new URLSearchParams(location.search);
  const mode = queryParams.get('mode');

  const isBuyNow = mode === 'buynow';
  const isCart = mode === 'cart' || !mode;

  const buynowItem = isBuyNow ? JSON.parse(sessionStorage.getItem('buynowProduct')) : null;

  useEffect(() => {
    if (isBuyNow && buynowItem) {
      setCartItems([buynowItem]);
      const total = buynowItem.price * buynowItem.quantity;
      setShippingFee(total > 500000 ? 0 : 30000);
    } else if (isCart) {
      const stored = localStorage.getItem('cartItems');
      if (stored) {
        const parsed = JSON.parse(stored);
        setCartItems(parsed);
        const subtotal = parsed.reduce((sum, item) => sum + item.price * item.quantity, 0);
        setShippingFee(subtotal > 500000 ? 0 : 30000);
      }
    }
  }, [mode, buynowItem]);

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = subtotal + shippingFee;

  if (cartItems.length === 0) {
    return <p style={{ textAlign: 'center', marginTop: '40px' }}>Không có sản phẩm để thanh toán.</p>;
  }

  return (
    <div className="checkout-container">
      <h1 className="checkout-title">Thông tin</h1>

      <div className="checkout-grid">
        {/* Địa chỉ nhận hàng */}
        <div className="checkout-section">
          <h3>Địa chỉ nhận hàng</h3>
          <input placeholder="Tên" />
          <input placeholder="Số điện thoại" />
          <input placeholder="Địa chỉ nhận hàng" />
        </div>

        {/* Phương thức thanh toán */}
        <div className="checkout-section">
          <h3>Phương thức thanh toán</h3>
          <p>Thanh toán khi nhận hàng</p>

          <h3 style={{ marginTop: '16px' }}>Phương thức vận chuyển</h3>
          <div className="shipping-option">
            <span>Giao hàng tiêu chuẩn</span>
            <span>{shippingFee.toLocaleString('vi-VN')} VND</span>
          </div>
        </div>

        {/* Sản phẩm */}
        <div className="checkout-section scrollable">
          <h3>Sản phẩm</h3>
          {cartItems.map((item) => (
            <div key={item.productId} className="product-item">
              <img src={item.urlImage} alt={item.productName} />
              <div className="info">
                <div>{item.productName}</div>
                <div>Số lượng: {item.quantity}</div>
              </div>
              <div>{item.price.toLocaleString('vi-VN')} VND</div>
            </div>
          ))}
        </div>

        {/* Ghi chú và tổng */}
        <div className="checkout-section">
          <h3>Thanh toán</h3>
          <textarea placeholder="Để lại lời nhắn" />
          <div className="summary">
            <div><span>Tổng tiền hàng</span><span>{subtotal.toLocaleString('vi-VN')} VND</span></div>
            <div><span>Phí vận chuyển</span><span>{shippingFee.toLocaleString('vi-VN')} VND</span></div>
            <div className="total">
              <span>Tổng thanh toán</span>
              <span>{total.toLocaleString('vi-VN')} VND</span>
            </div>
          </div>
        </div>
      </div>

      <div className="checkout-actions">
        {!isBuyNow && (
          <button className="back-btn" onClick={() => navigate('/cart')}>
            ← Quay lại giỏ hàng
          </button>
        )}
        <button className="checkout-btn">
          Hoàn tất đơn hàng
        </button>
      </div>
    </div>
  );
};

export default Checkout;
