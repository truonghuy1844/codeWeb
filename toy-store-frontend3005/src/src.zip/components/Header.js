import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import MiniCartPopup from './MiniCartPopup';
import './Header.css';

const Header = ({ onUpdateQty }) => {
  const [showCart, setShowCart] = useState(false);
  const [keyword, setKeyword] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    if (e.key === 'Enter' && keyword.trim() !== '') {
      navigate(`/products?keyword=${encodeURIComponent(keyword.trim())}`);
    }
  };

  return (
    <header className="header">
      <div className="top-bar">
        <span>🚚 Miễn phí giao hàng từ đơn 500k</span>
        <div className="top-links">
          <Link to="/login">Đăng nhập</Link>
          <Link to="/register">Đăng ký</Link>
        </div>
      </div>

      <nav className="nav-bar">
        <div className="logo">
          <h1>🎁 TOY STORE</h1>
        </div>

        <ul className="menu">
          <li><Link to="/">Trang chủ</Link></li>
          <li><Link to="/products">Sản phẩm</Link></li>
          <li><Link to="/promotions">Khuyến mãi</Link></li>
          <li><Link to="/account">Tài khoản</Link></li>
        </ul>

        <div className="search-cart">
          <input
            type="text"
            placeholder="🔍 Tìm kiếm sản phẩm..."
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            onKeyDown={handleSearch}
          />

          {/* Bọc cả icon và popup để xử lý hover */}
          <div
            className="cart-hover-area"
            onMouseEnter={() => setShowCart(true)}
            onMouseLeave={() => setShowCart(false)}
            style={{ position: 'relative', display: 'inline-block' }}
          >
            <Link to="/cart" className="cart-icon">Giỏ hàng</Link>

            {showCart && (
              <div
                className="popup-wrapper"
                style={{
                  position: 'absolute',
                  top: 'calc(100% + 8px)',
                  right: 0,
                  zIndex: 9999,
                }}
              >
                <MiniCartPopup
                  onClose={() => setShowCart(false)}
                  onUpdateQty={onUpdateQty}
                />
              </div>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;
