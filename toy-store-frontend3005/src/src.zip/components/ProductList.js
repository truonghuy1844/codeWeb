import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import './ProductList.css';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('http://localhost:5228/api/product')
      .then((response) => {
        setProducts(response.data.data);
      })
      .catch((error) => {
        console.error('❌ Lỗi khi gọi API:', error);
      });
  }, []);

  const handleBuyNow = (product) => {
    const selectedItem = {
      productId: product.productId,
      productName: product.name,
      quantity: 1,
      price: product.price1,
      urlImage: product.urlImage1
    };

    sessionStorage.setItem('buynowProduct', JSON.stringify(selectedItem));
    navigate('/checkout?mode=buynow');
  };

  return (
    <div className="product-list">
      {products.length === 0 ? (
        <p>Đang tải sản phẩm...</p>
      ) : (
        products.map((p) => (
          <div className="product-card" key={p.productId}>
            <Link to={`/product/${p.productId}`} style={{ textDecoration: 'none', color: 'inherit' }}>
              <img src={p.urlImage1 || 'https://via.placeholder.com/150'} alt={p.name} />
              <h3>{p.name}</h3>
              <p>{p.price1?.toLocaleString('vi-VN')} ₫</p>
            </Link>
            <button onClick={() => handleBuyNow(p)}>🛒 Mua hàng</button>
          </div>
        ))
      )}
    </div>
  );
};

export default ProductList;
