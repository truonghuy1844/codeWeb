import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './MiniCartPopup.css';

const MiniCartPopup = ({ onUpdateQty, showClose = true }) => {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = () => {
    const stored = JSON.parse(localStorage.getItem('cartItems')) || [];
    setItems(stored);
    const sum = stored.reduce((acc, item) => acc + item.price * item.quantity, 0);
    setTotal(sum);
  };

  const handleRemoveItem = (productId) => {
    const updated = items.filter(item => item.productId !== productId);
    localStorage.setItem('cartItems', JSON.stringify(updated));
    setItems(updated);
    const sum = updated.reduce((acc, item) => acc + item.price * item.quantity, 0);
    setTotal(sum);
  };

  const handleUpdateQty = (productId, delta) => {
    if (typeof onUpdateQty === 'function') {
      onUpdateQty(productId, delta);
      setTimeout(() => loadCart(), 50);
    }
  };

  return (
    <div className="mini-cart-popup">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3>Giỏ hàng</h3>
      </div>

      {items.length === 0 ? (
        <p>Chưa có sản phẩm nào.</p>
      ) : (
        <>
          {items.map(item => (
            <div className="cart-item" key={item.productId}>
              <img src={item.urlImage} alt={item.productName} />
              <div className="cart-details">
                <div className="cart-name">{item.productName}</div>
                <div className="cart-price">{item.price.toLocaleString('vi-VN')} ₫</div>
                <div className="qty-box">
                  <button onClick={() => handleUpdateQty(item.productId, -1)}>-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => handleUpdateQty(item.productId, 1)}>+</button>
                </div>
              </div>
              <button onClick={() => handleRemoveItem(item.productId)}>✕</button>
            </div>
          ))}

          <div className="total-summary">
            Tổng cộng: <span>{(total || 0).toLocaleString('vi-VN')} ₫</span>
          </div>

          <div className="cart-buttons">
            <button className="view-cart" onClick={() => navigate('/cart')}>Xem giỏ hàng</button>
            <button className="checkout" onClick={() => navigate('/checkout')}>Thanh toán ngay</button>
          </div>
        </>
      )}
    </div>
  );
};

export default MiniCartPopup;
